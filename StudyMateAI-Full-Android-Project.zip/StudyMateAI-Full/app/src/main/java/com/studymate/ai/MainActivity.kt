package com.studymate.ai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

private val BG = Color(0xFF07090D)
private val PANEL = Color(0xFF141923)
private val NEON = Color(0xFFB8FF35)
private val CYAN = Color(0xFF42E8FF)
private val MUTED = Color(0xFF9AA3B2)
private const val PREFS = "studymate_local"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyMateApp(this) }
    }
}

@Composable
fun StudyMateApp(context: Context) {
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("Home") }
    var backend by remember { mutableStateOf(prefs.getString("backend", "") ?: "") }
    var question by remember { mutableStateOf("") }
    var aiAnswer by remember { mutableStateOf("Namaste! Ask me anything about DBMS or DSP Python.") }
    var busy by remember { mutableStateOf(false) }
    var noteTopic by remember { mutableStateOf("Database normalization") }
    var noteText by remember { mutableStateOf(prefs.getString("notes", "Your generated notes will appear here.") ?: "") }
    var schedule by remember { mutableStateOf(prefs.getString("schedule", "07:00 | DBMS revision\\n17:00 | DBMS lesson\\n17:45 | DSP Python practice\\n20:30 | Daily quiz") ?: "") }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var correct by remember { mutableIntStateOf(prefs.getInt("correct", 0)) }
    val scope = rememberCoroutineScope()
    val tabs = listOf("Home", "AI Tutor", "Notes", "Timetable", "Quiz", "Progress")
    MaterialTheme(colorScheme = darkColorScheme(background=BG, surface=PANEL, primary=NEON, secondary=CYAN, onBackground=Color.White, onSurface=Color.White)) {
        Scaffold(containerColor=BG, bottomBar={
            NavigationBar(containerColor=PANEL) {
                tabs.forEach { t ->
                    NavigationBarItem(selected=tab==t, onClick={tab=t},
                        icon={ Icon(when(t) {
                            "Home"->Icons.Default.Home; "AI Tutor"->Icons.Default.AutoAwesome
                            "Notes"->Icons.Default.Description; "Timetable"->Icons.Default.CalendarMonth
                            "Quiz"->Icons.Default.Quiz; else->Icons.Default.Insights
                        }, contentDescription=t) },
                        label={Text(t,fontSize=9.sp)},
                        colors=NavigationBarItemDefaults.colors(selectedIconColor=NEON,indicatorColor=Color(0xFF29351B),selectedTextColor=NEON,unselectedTextColor=MUTED))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=17.dp)) {
                Row(Modifier.fillMaxWidth().padding(top=15.dp,bottom=14.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("STUDYMATE",color=NEON,fontWeight=FontWeight.Black,letterSpacing=3.sp,fontSize=13.sp)
                        Text("FREE LEARNING FOR EVERYONE",color=MUTED,fontSize=9.sp,letterSpacing=1.sp)
                    }
                    Text("● ONLINE AI",color=CYAN,fontSize=10.sp,fontWeight=FontWeight.Bold)
                }
                when(tab) {
                    "Home" -> HomeScreen(completed, correct) { tab=it }
                    "AI Tutor" -> {
                        PageTitle("AI Tutor","DBMS + DSP Python • English + Hindi")
                        CardBox {
                            Text("Ask your doubt",color=NEON,fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(question,{question=it},modifier=Modifier.fillMaxWidth(),minLines=3,
                                placeholder={Text("Explain SQL joins with examples...",color=MUTED)},colors=fieldColors())
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(backend,{backend=it; prefs.edit().putString("backend",it).apply()},modifier=Modifier.fillMaxWidth(),
                                singleLine=true,label={Text("Your deployed HTTPS backend URL")},colors=fieldColors())
                            Spacer(Modifier.height(8.dp))
                            Button(onClick={
                                busy=true
                                scope.launch { aiAnswer=callBackend(backend,"/ask",question); busy=false }
                            },enabled=!busy && question.isNotBlank() && backend.startsWith("https://"),
                                colors=ButtonDefaults.buttonColors(containerColor=NEON,contentColor=BG)) {
                                if(busy) CircularProgressIndicator(Modifier.size(17.dp),color=BG,strokeWidth=2.dp)
                                else Icon(Icons.Default.Send,null)
                                Spacer(Modifier.width(7.dp)); Text(if(busy)"Thinking..." else "Ask AI")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        CardBox { Text("ANSWER",color=CYAN,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(aiAnswer,lineHeight=21.sp) }
                    }
                    "Notes" -> {
                        PageTitle("Smart Notes","Generate concise revision notes")
                        CardBox {
                            var subject by remember { mutableStateOf("DBMS") }
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                listOf("DBMS","DSP Python").forEach { FilterChip(selected=subject==it,onClick={subject=it},label={Text(it)}) }
                            }
                            OutlinedTextField(noteTopic,{noteTopic=it},modifier=Modifier.fillMaxWidth(),label={Text("Topic")},colors=fieldColors())
                            Spacer(Modifier.height(8.dp))
                            Button(onClick={
                                busy=true
                                scope.launch {
                                    val prompt="Create clear revision notes in simple English + Hindi for $subject topic: $noteTopic. Include definition, key points, one example, common mistakes and 5 exam questions."
                                    noteText=callBackend(backend,"/ask",prompt)
                                    prefs.edit().putString("notes",noteText).apply()
                                    busy=false
                                }
                            },enabled=!busy && backend.startsWith("https://"),colors=ButtonDefaults.buttonColors(containerColor=NEON,contentColor=BG)) {
                                Text(if(busy)"Generating..." else "Generate notes with AI")
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        CardBox { Text("YOUR NOTES",color=CYAN,fontWeight=FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(noteText,lineHeight=20.sp) }
                    }
                    "Timetable" -> {
                        PageTitle("Study timetable","Edit and save your daily plan")
                        CardBox {
                            OutlinedTextField(schedule,{schedule=it;prefs.edit().putString("schedule",it).apply()},
                                modifier=Modifier.fillMaxWidth(),minLines=8,label={Text("One task per line: time | task")},colors=fieldColors())
                            Text("Example: 18:00 | Practice Python loops",color=MUTED,fontSize=11.sp)
                        }
                    }
                    "Quiz" -> QuizScreen { wasCorrect ->
                        completed++; if(wasCorrect) correct++
                        prefs.edit().putInt("completed",completed).putInt("correct",correct).apply()
                    }
                    "Progress" -> ProgressScreen(completed,correct)
                }
            }
        }
    }
}

@Composable fun HomeScreen(done:Int, correct:Int, open:(String)->Unit) {
    Text("Learn smarter.",fontSize=29.sp,fontWeight=FontWeight.Black)
    Text("Small daily steps. Strong results.",color=MUTED)
    Spacer(Modifier.height(16.dp))
    CardBox {
        Text("TODAY'S STUDY GOAL",color=NEON,fontWeight=FontWeight.Bold,fontSize=11.sp)
        Text("DBMS + DSP Python",fontSize=22.sp,fontWeight=FontWeight.Bold)
        Text("45 min learning • 15 min practice",color=MUTED)
        Spacer(Modifier.height(8.dp))
        Button(onClick={open("AI Tutor")},colors=ButtonDefaults.buttonColors(containerColor=NEON,contentColor=BG)){Text("Start learning")}
    }
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
        StatCard("Quiz attempts","$done",Modifier.weight(1f))
        StatCard("Correct","$correct",Modifier.weight(1f))
    }
    listOf("AI Tutor" to "Ask doubts step by step","Notes" to "Make exam-ready notes","Timetable" to "Plan your study day","Quiz" to "Check your understanding","Progress" to "Review your activity").forEach { (title,desc) ->
        CardBox(Modifier.fillMaxWidth().padding(top=8.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold);Text(desc,color=MUTED,fontSize=12.sp)}
                Icon(Icons.Default.ChevronRight,null,tint=NEON)
            }
        }
    }
}
@Composable fun QuizScreen(onResult:(Boolean)->Unit) {
    var choice by remember { mutableIntStateOf(-1) }
    var checked by remember { mutableStateOf(false) }
    PageTitle("Daily quiz","DBMS • Primary keys")
    CardBox {
        Text("QUESTION 1",color=NEON,fontWeight=FontWeight.Bold)
        Text("Which key uniquely identifies each row in a database table?",fontSize=18.sp,fontWeight=FontWeight.SemiBold)
        listOf("Foreign key","Primary key","Alternate key","Composite attribute").forEachIndexed { i,s ->
            Row(Modifier.fillMaxWidth().clickable{choice=i;checked=false}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically) {
                RadioButton(choice==i,{choice=i;checked=false},colors=RadioButtonDefaults.colors(selectedColor=NEON)); Text(s)
            }
        }
        Button(onClick={if(!checked){onResult(choice==1);checked=true}},enabled=choice>=0&&!checked,colors=ButtonDefaults.buttonColors(containerColor=NEON,contentColor=BG)){Text("Submit answer")}
        if(checked) Text(if(choice==1)"Correct! Primary key identifies a row." else "Correct answer: Primary key.",color=CYAN)
    }
}
@Composable fun ProgressScreen(done:Int,correct:Int) {
    PageTitle("Your progress","Your activity on this device")
    Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
        StatCard("Attempts","$done",Modifier.weight(1f))
        StatCard("Correct","$correct",Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    CardBox { Text("Keep going!",color=NEON,fontSize=21.sp,fontWeight=FontWeight.Bold); Text("Study a little every day. Your quiz totals are saved locally on this device.",color=MUTED) }
}
@Composable fun PageTitle(title:String,subtitle:String) {
    Text(title,fontSize=26.sp,fontWeight=FontWeight.Bold)
    Text(subtitle,color=MUTED,fontSize=12.sp)
    Spacer(Modifier.height(13.dp))
}
@Composable fun StatCard(label:String,value:String,modifier:Modifier=Modifier) {
    CardBox(modifier) { Text(label,color=MUTED,fontSize=11.sp); Text(value,color=NEON,fontSize=29.sp,fontWeight=FontWeight.Black) }
}
@Composable fun CardBox(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Card(modifier=modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=PANEL)) {
        Column(Modifier.fillMaxWidth().padding(15.dp),content=content)
    }
}
@Composable fun fieldColors()=OutlinedTextFieldDefaults.colors(
    focusedBorderColor=NEON,unfocusedBorderColor=Color(0xFF454B59),focusedLabelColor=NEON,
    cursorColor=NEON,focusedTextColor=Color.White,unfocusedTextColor=Color.White
)
suspend fun callBackend(base:String,path:String,message:String):String = withContext(Dispatchers.IO) {
    try {
        val body=JSONObject().put("message",message).put("language","English + Hindi")
            .toString().toRequestBody("application/json".toMediaType())
        val request=Request.Builder().url(base.trimEnd('/')+path).post(body).build()
        OkHttpClient().newCall(request).execute().use { response ->
            val text=response.body?.string().orEmpty()
            if(!response.isSuccessful) "AI service error: ${response.code}. ${runCatching{JSONObject(text).optString("error")}.getOrDefault("")}"
            else JSONObject(text).optString("answer","No answer returned.")
        }
    } catch(e:Exception) { "Could not reach AI server. Check your HTTPS backend URL and internet connection." }
}
