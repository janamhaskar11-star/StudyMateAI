# StudyMate AI — Black Neon Android app

## Features in this starter build
- Native Android app built with Kotlin + Jetpack Compose
- Black neon visual style; English + Hindi tutor instructions
- Home dashboard, AI Tutor, AI Notes prompt/generation, editable timetable, DBMS quiz and local progress counters
- Progress and timetable/notes/backend URL saved locally on the device
- Node.js backend proxy for AI requests; API key stays on the server, not in the APK

## Build the APK
1. Install Android Studio on a computer and open this project folder.
2. Allow Gradle sync; install Android SDK 35 if prompted.
3. Run on an Android emulator/device to test.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.
6. For Play Store/direct distribution, use Build > Generate Signed Bundle / APK and create a private signing key. Keep it backed up.

## Enable full AI
1. Install Node.js on a server.
2. In `backend/`, run `npm install`.
3. Set `OPENAI_API_KEY` as a server environment variable. Optional: `OPENAI_MODEL`.
4. Run `npm start`, then deploy behind HTTPS.
5. In app > AI Tutor, enter the deployed HTTPS backend URL.
6. The Notes screen uses the same `/ask` AI endpoint.

Never place API keys in Android source code or APK. AI provider usage may cost money. A no-subscription app can still have hosting/API costs.

## Honest scope
This is a functional starter project, not a certified or production-ready commercial release. The included quiz is a sample DBMS quiz, progress counters are local to one device, and there is no login/cloud sync, payment system, privacy-policy page, large course library, or automated AI quiz bank yet. Thoroughly test, add privacy disclosures and secure backend rate limits before public release.
