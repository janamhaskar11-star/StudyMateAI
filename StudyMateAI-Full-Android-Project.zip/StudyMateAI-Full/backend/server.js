const express = require("express");
const app = express();
app.use(express.json({limit:"1mb"}));
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.get("/health", (_,res)=>res.json({ok:true,name:"StudyMate AI"}));
app.post("/ask", async (req,res)=>{
  try {
    if(!API_KEY) return res.status(503).json({error:"AI backend is not configured yet."});
    const message=String(req.body?.message||"").slice(0,8000);
    if(!message.trim()) return res.status(400).json({error:"Message required"});
    const r=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{"Authorization":`Bearer ${API_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:MODEL,
        instructions:"You are StudyMate AI, a friendly tutor. Teach DBMS and Digital Signal Processing with Python. Reply in simple English and Hindi. Use headings, step-by-step explanations, examples, exam tips and runnable Python code where relevant. Never invent facts. For notes, create structured revision notes. For quizzes, ask one question at a time unless asked for a set.",
        input:message
      })
    });
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data.error?.message||"AI provider error"});
    const answer=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\\n");
    res.json({answer:answer||"Please try asking in a different way."});
  } catch(e) { console.error(e); res.status(500).json({error:"Internal server error"}); }
});
app.listen(PORT,()=>console.log(`StudyMate backend listening on ${PORT}`));
